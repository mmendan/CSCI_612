#include <opencv2/opencv.hpp>
#include <iostream>
#include <vector>
using namespace cv;
using namespace std;

int main(int argc, char* argv[])
{
    VideoCapture cap("/home/bots/Desktop/Assignment_3/Q5/Output/out.mp4");
	if (!cap.isOpened())
        {
            cout<<"No camera or video input!\n"<<endl;
            return -1;
        }
 
    string window_name = "My Camera Feed";
    namedWindow(window_name,WINDOW_NORMAL); //creates window "My Camera Feed"
    resizeWindow("My Camera Feed",640,480);
    int n = 1;
    while (true)
    {
	Mat f;
	Mat thr;
        cap>>f; // reads new frame fro camera	
	threshold(f, thr, 127, 255, THRESH_BINARY );
	vector<vector<int>> v;
	Scalar intensity ;
	for(int i=0; i<=f.rows; i++) //gets every pixel of frame
	{
  		for(int j=0; j<=f.cols; j++) 
		{	
			int val = f.at<Vec3b>(i,j)[0];
			if(val==255) //store coordinates of pixel in the vector of vector, if the pixel intesity is equal to 255
			{
				vector<int> v1;
				v1.push_back(i);
				v1.push_back(j);
				v.push_back(v1);
			}
		}
	}
	int xLeft=1920;
	for(int i = 0; i<v.size(); ++i)//gets the xLeft value - min value of x
	{
			if(v[i][0]<xLeft)
			{
				xLeft = v[i][0];
			}		
	}	
	int yTop=1920;
	for(int i = 0; i<v.size(); ++i)//gets yTop value - min value of y
	{
			if(v[i][1]<yTop)
			{
				yTop = v[i][1];
			}		
	}	
	int xright=0;
	for(int i = 0; i<v.size(); ++i)//gets the xright value - max value of x
	{
			if(v[i][0]>xright)
			{
				xright = v[i][0];
			}		
	}	
	int ybottom=0;
	for(int i = 0; i<v.size(); ++i)//gets the ybottom value - maxi value of y
	{
			if(v[i][1]>ybottom)
			{
				ybottom = v[i][1];
			}		
	}	
	vector<Mat> rgb;//spits the frame in rbg
	split(thr,rgb);
	double Ybar = (ybottom-yTop)/2 + yTop;
	double Xbar = (xright-xLeft)/2 + xLeft;
	Point p(Ybar, Xbar);//creates a point on Ybar and Xbar
	drawMarker(rgb[1],p, Scalar(255,255,255),MARKER_CROSS,50,5);
	string name = "/home/bots/Desktop/Assignment_3/Que6/Output/" + std::to_string(n) + ".pgm";
	imwrite(name,rgb[1]);// wrote the image files in a folder to covert it into video frame
        if (waitKey(10) == 27)
        {
            cout << "Esc key is pressed by the user. Stopping the video" << endl;
            break;
        }
	n+=1;
    }   
    return 0;
}
