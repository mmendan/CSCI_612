


#include "opencv2/imgcodecs.hpp"
#include "opencv2/highgui.hpp"
#include "opencv2/imgproc.hpp"
#include "opencv2/imgproc.hpp"
#include <opencv2/core/core.hpp>
 
#include <vector> 
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
 
#define ESCAPE_KEY (27)
#define SYSTEM_ERROR (-1)
 
using namespace cv;
using namespace std;
 
 
int main(int argc, char** argv)

{
    Mat src, gray;// assign a varaible 
    char winInput = 'n';

    VideoCapture cam0(0);// writing code to open the camera
 
    if (!cam0.isOpened())
        exit(SYSTEM_ERROR);
 
    cam0.set(CAP_PROP_FRAME_WIDTH, 640);
    cam0.set(CAP_PROP_FRAME_HEIGHT, 480);
 
 
    while (1)
    {
        cam0.read(src);
 
        vector<Vec3f> circles;
 
        cvtColor(src, gray, COLOR_RGB2GRAY);
        medianBlur(gray, gray, 5);
        HoughCircles(gray, circles, HOUGH_GRADIENT, 1,
                 gray.rows/16,  // change this value to detect circles with different distances to each other
                 100, 30, 1, 30 // change the last two parameters
            // (min_radius & max_radius) to detect larger circles
        );
        
        for( size_t i = 0; i < circles.size(); i++ )
        {
            Vec3i c = circles[i];
            Point center = Point(c[0], c[1]);
            // circle center
            circle( src, center, 1, Scalar(0,100,100), 3, LINE_AA);
            // circle outline
            int radius = c[2];
            circle( src, center, radius, Scalar(255,0,255), 3, LINE_AA);
        }
        
        imshow("detected circles", src);
        
        if ((winInput = waitKey(5)) == ESCAPE_KEY)
            break;
    }
 
    waitKey(1);
    return 0;
}
 

 
