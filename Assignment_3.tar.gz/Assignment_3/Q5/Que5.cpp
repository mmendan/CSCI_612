
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
 
#include "opencv2/core.hpp"
#include "opencv2/highgui.hpp"
#include "opencv2/imgproc.hpp"
 
using namespace cv;
using namespace std;
 
 
int main( int argc, char** argv )
{
    Mat mat_frame, greenBand;
    Mat array[3];
 
    VideoCapture vcap("Dark-Room-Laser-Spot.mpeg");
    
    unsigned count = 0; 
    
    while(1)
    {
        count++;
        if(!vcap.read(mat_frame)) 
        {
            cout << "No frame" << std::endl;
            return 0;
        }
        
	    //this will split the image into frames
        split(mat_frame, array);

	    // taking green band into  png images as array.   
        greenBand = array[1];
 
        imwrite( format("Output/Output%04d.pgm", count), greenBand );
	    cout<<"Dumped Frame #"<<count<<endl;
 
        waitKey(1); 
    
    }
};
