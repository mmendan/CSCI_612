

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
 
#include "opencv2/core.hpp"
#include "opencv2/highgui.hpp"
#include "opencv2/imgproc.hpp"
 
using namespace cv;
using namespace std;
 
int main( int argc, char** argv )
{
    Mat mat_frame, mat_gray, mat_diff, mat_gray_prev,image1,image2,image3;
    unsigned diffsum, maxdiff;
    double percent_diff;
    char difftext[20];
    
    namedWindow( "Color Example");
    namedWindow( "Color Previous");    
    namedWindow( "Color Diff");
    
     
    VideoCapture vcap("Dark-Room-Laser-Spot-with-Clutter.mpeg");
 
    while(!vcap.read(mat_frame)) 
    {
        cout << "No frame" << endl;
        waitKey(33);
    }

    // Clone original frame and store it in mat_diff and mat_gray_prev  
    mat_diff = mat_frame.clone();
    mat_gray_prev = mat_frame.clone();

    // worst case sum is resolution * 255
    maxdiff = (mat_diff.cols)*(mat_diff.rows)*255;
 
    while(1)
    {
        if(!vcap.read(mat_frame)) 
        {
            cout << "No more frames" << endl;
            break;
        }
       
	    // Take difference between previous and current frame and store it in mat_diff
        absdiff(mat_gray_prev, mat_frame, mat_diff);
 
        
        diffsum = (unsigned int)cv::sum(mat_diff)[0]; // single channel sum
 
        percent_diff = ((double)diffsum / (double)maxdiff)*100.0;
 
        cout<<"percent diff = "<<percent_diff<<endl;
        sprintf(difftext, "%8d",  diffsum);
    
        if(percent_diff > 0.5) 
            putText(mat_diff, difftext, Point(30,30), FONT_HERSHEY_COMPLEX_SMALL, 0.8, Scalar(200,200,250), 1, LINE_AA);

	    // resize images
	    resize(mat_frame, image1, Size(mat_frame.cols/3, mat_frame.rows/3)); 
	    resize(mat_gray_prev, image2, Size(mat_gray_prev.cols/3, mat_gray_prev.rows/3)); 
	    resize(mat_diff, image3, Size(mat_diff.cols/3, mat_diff.rows/3)); 
		
	    // Show results 
        imshow("Color Example", image1);
        imshow("Color Previous", image2);
        imshow("Color Diff", image3);
 
        waitKey(1);
 
        mat_gray_prev = mat_frame.clone();
    }
 
    destroyWindow("Color Example");
    destroyWindow("Color Previous");
    destroyWindow("Color Diff");
    return 0;
};

